# ADR-013: Self-Hosting / Free-First Strategy

## الحالة (Status)
Accepted

## السياق (Context)
منصة Ibn Al-Azhar Docs — ابن الأزهر دوكس تستهدف مؤسسات تعليمية في العالم العربي، الكثير منها لديه ميزانيات تقنية محدودة. النموذج السائد في السوق هو الاشتراكات الشهرية لخدمات سحابية (SaaS)، لكن هذا لا يناسب المؤسسات الصغيرة والمتوسطة. نحتاج إلى قرار استراتيجي: هل نبني المنصة كخدمة سحابية مدفوعة، أم كمنصة يمكن استضافتها ذاتيًا بتكلفة شبه مجانية، أم مزيجًا من الاثنين؟ القرار يؤثر على البنية التقنية بالكامل: اختيار قواعد البيانات، التخزين، قوائم الانتظار، وتكلفة التشغيل. هدفنا هو تقليل التكلفة الشهرية للحد الأدنى مع الحفاظ على جودة الخدمة.

## القرار (Decision)
قررنا اعتماد استراتيجية **Self-hosting / Free-first**:
- جميع المكونات يمكن تشغيلها على VPS واحد بتكلفة ~$6/شهر (Hetzner أو DigitalOcean)
- لا اعتماد على خدمات سحابية مدفوعة (لا AWS، لا Supabase، لا PlanetScale)
- MinIO بدلاً من S3، PostgreSQL بدلاً من Supabase، Redis بدلاً من ElastiCache
- Caddy كـ reverse proxy مع HTTPS تلقائي (Let's Encrypt)
- Docker Compose لنشر جميع الخدمات معًا
- يمكن لاحقًا تقديم خطة سحابية مدفوعة (managed hosting) كمصدر دخل

## البدائل المعتبرة (Options Considered)

### 1. Self-hosted على VPS واحد — Free-first (المختار)
- **المميزات:** تكلفة منخفضة جدًا (~$6/شهر)، تحكم كامل في البيانات والبنية، لا vendor lock-in، خصوصية البيانات (كل شيء على خادمنا)، يمكن للمؤسسات استضافته على خوادمهم الخاصة، قابل للتوسع التدريجي
- **العيوب:** عبء تشغيلي (operational burden): صيانة، تحديثات، نسخ احتياطي، مراقبة، نقطة فشل واحدة (single VPS = single point of failure)، يحتاج خبرة DevOps، لا scaling تلقائي

### 2. Cloud-managed services (SaaS model)
- **المميزات:** لا إدارة بنية تحتية، scaling تلقائي، موثوقية عالية، تحديثات تلقائية، يمكن التركيز على المنتج
- **العيوب:** تكلفة شهرية عالية (~$50-200/شهر للمبتدئين)، خصوصية البيانات (خوادم خارجية)، vendor lock-in، لا يناسب المؤسسات ذات الميزانيات المحدودة، تعتمد على مزودي الخدمة

### 3. Hybrid (بعض الخدمات self-hosted + بعضها cloud)
- **المميزات:** توازن بين التكلفة والموثوقية، يمكن اختيار أفضل حل لكل مكون
- **العيوب:** تعقيد في إدارة بيئتين، مشاكل latency بين self-hosted و cloud، تكلفة لا يمكن التنبؤ بها، صعوبة في debugging

### 4. Serverless / Function-as-a-Service
- **المميزات:** لا إدارة خوادم، دفع مقابل الاستخدام فقط، scaling تلقائي فوري
- **العيوب:** تكلفة غير متوقعة مع الاستخدام المرتفع، cold starts، حدود وقت التنفيذ، لا يناسب عمليات طويلة مثل OCR، اعتماد على مزود سحابي

## البنية المقترحة على VPS واحد

| المكون | التقنية | الموارد المقدرة |
|---|---|---|
| التطبيق | Next.js (Docker) | ~256MB RAM |
| قاعدة البيانات | PostgreSQL 16 (Docker) — DB name: `ibn_al_azhar_docs` | ~256MB RAM |
| التخزين | MinIO (Docker) — bucket: `ibn-al-azhar-docs-files` | يعتمد على الملفات |
| طوابير المهام | Redis + BullMQ Workers (Docker) | ~128MB RAM |
| Reverse Proxy | Caddy (Docker) — HTTPS تلقائي | ~32MB RAM |
| **المجموع** | | **~700MB RAM** |

**VPS الموصى به:** 2 vCPU + 4GB RAM + 40GB SSD (~$6/شهر على Hetzner)

## العواقب (Consequences)
- **إيجابية:** تكلفة تشغيل منخفضة جدًا تجعل المنصة متاحة للجميع (free-first)، تحكم كامل في البنية والبيانات، لا vendor lock-in، يمكن للمؤسسات تشغيله على خوادمهم (on-premise)، نموذج أعمال مرن (free self-hosted + paid managed)، Caddy يبسّط إدارة HTTPS والـ reverse proxy
- **سلبية:** عبء تشغيلي كبير (backups، updates، monitoring، security patches)، نقطة فشل واحدة (إذا تعطل VPS، تتوقف المنصة بالكامل)، لا scaling أفقي تلقائي، يحتاج فريق DevOps أو مهارات تشغيلية، recovery time أطول عند الأعطال
- **مخاطر:** إذا نما عدد المستخدمين بشكل كبير، VPS واحد لن يكفي. الحل: الانتقال التدريجي إلى بنية موزعة (separate database server، worker servers)، أو تقديم خطة مدفوعة على بنية سحابية.

## المتابعة (Follow-up)
- إنشاء Docker Compose file لجميع الخدمات
- كتابة دليل نشر (Deployment Guide) خطوة بخطوة
- إعداد Caddy كـ reverse proxy مع HTTPS تلقائي (Let's Encrypt)
- تصميم استراتيجية النسخ الاحتياطي (daily PostgreSQL dumps + MinIO sync)
- إعداد monitoring أساسي (Uptime Kuma أو Prometheus + Grafana)
- كتابة scripts للتحديث التلقائي (watchtower أو custom)
- اختبار النشر الكامل على VPS تجريبي
- توثيق متطلبات النظام الأدنى
